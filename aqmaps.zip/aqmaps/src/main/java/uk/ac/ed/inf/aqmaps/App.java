package uk.ac.ed.inf.aqmaps;

import java.io.IOException;



/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws NumberFormatException, IOException, InterruptedException
    {
    	//parsing all the data
        String day = args[0];
        String month = args[1];
        String year = args[2];
        String latitude = args[3];
        String longitude = args[4];
        String rnd = args[5];
        String port = args[6];
        
        Route r = new Route(day,month,year,latitude,longitude,rnd,port);
		r.start();
      
    }
}
