package uk.ac.ed.inf.aqmaps;

import java.io.IOException;

import com.google.gson.Gson;
import com.mapbox.geojson.Feature;
import com.mapbox.geojson.Point;


public class Sensor {
	public String location;
	private double battery;
	private String reading;
	public Feature feature;

	
	public Feature toFeature(String port) throws IOException, InterruptedException 
	{
		feature = Feature.fromGeometry(this.getCoordinate(port));
		return feature;
	}
	//after we read the sensor, we transfer it to the desire feature
	public Feature addStringProperty(){
		String[] colorStr =  this.colorStr();
		feature.addStringProperty("marker-size", "medium");
		feature.addStringProperty("location", this.location);
		feature.addStringProperty("rgb-string", colorStr[0]);
		feature.addStringProperty("marker-color", colorStr[0]);
		feature.addStringProperty("marker-symbol", colorStr[2]);
		return feature;
	}
	
	private String[] colorStr() 
	{
		double x = -1;
		if(this.battery <= 10) 
		{
			return new String[] {"#000000","Black","cross"};
		}
		if(this.reading.equals("Nan")||this.reading.equals("null")){ x = -1;}
		else {x = Double.parseDouble(reading);}
		
		if(x<32 && x>=0){
    		return new String[] {"#00ff00","Green","lighthouse"};//Green
    	}
    	else if(x<64){
    		return new String[] {"#40ff00","Medium Green","lighthouse"};//Medium Green
    	}
    	else if(x<96){
    		return new String[] {"#80ff00","Light Green","lighthouse"};//Light Green
    	}
    	else if(x<128){
    		return new String[] {"#c0ff00","Lime Green","lighthouse"};//Lime Green
    	}
    	else if(x<160){
    		return new String[] {"#ffc000","Gold","danger"};//Gold 
    	}
    	else if(x<192){
    		return new String[] {"#ff8000","Orange","danger"};//Orange
    	}
    	else if(x<224){    	
    		return new String[] {"#ff4000","Red/Orange","danger"};//Red or Orange
    	}
    	else if(x<256){
    		return new String[] {"#ff0000","Red","danger"};//Red 
    	}
		
		return new String[] {"#aaaaaa","Gray",""};//Gray
	}
	
	//search the coordinate of the sensor according to its w3words
	public Point getCoordinate(String port) throws IOException, InterruptedException {
		String words[] = this.location.split("\\.");
		String locstring = "http://localhost:"+port+"/words/"+words[0]+"/"+words[1]+"/"+words[2]+"/details.json";
		String lnglatString = JsonAPI.downloadAndParse(locstring);
		LocationDetail loc = new Gson().fromJson(lnglatString, LocationDetail.class);
		return Point.fromLngLat(loc.coordinates.lng,loc.coordinates.lat);
	}
}
