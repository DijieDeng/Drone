package uk.ac.ed.inf.aqmaps;

import java.util.ArrayList;

import com.mapbox.geojson.Point;

public class Loggers{

	private ArrayList<Integer> angles;
	private ArrayList<Point> route;
	
	public Loggers() 
	{
		this.angles = new ArrayList<>();
		new ArrayList<>();
		this.route = new ArrayList<>();
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public void addRoute(ArrayList<Point> in) {
		for(var i : in){
			this.route.add(i);
		}
	}

	public void addAngles(ArrayList<Integer> in) {
		for(var i : in){
			this.angles.add(i);
		}
	}

}
