package uk.ac.ed.inf.aqmaps;

import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse.BodyHandlers;


public class JsonAPI {
	
	//download and parse the json file
	public static String downloadAndParse(String urlString) throws IOException, InterruptedException {
	    var client = HttpClient.newHttpClient();
	    var request = HttpRequest.newBuilder()
	    .uri(URI.create(urlString))
	    .build();
	    var response = client.send(request, BodyHandlers.ofString());
	    return response.body();//sb.toString();
	}
	
	//write geojson file with 33 sensor points and 1 line string
	public static void writeGeojson(String arg,String day,String month,String year) 
	{
		try {
		      FileWriter myWriter = new FileWriter("readings-"+day+"-"+month+"-"+year+".geojson");
		      myWriter.write(arg);
		      myWriter.close();
		     // System.out.println("Successfully wrote to the file.");
		    } catch (IOException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
	}
	
// Write the fly route 
	public static void writetxt(String arg,String day,String month,String year) 
	{
		try {
		      FileWriter myWriter = new FileWriter("flightpath-"+day+"-"+month+"-"+year+".txt");
		      myWriter.write(arg);
		      myWriter.close();
		     //System.out.println("Successfully wrote to the file.");
			} catch (IOException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
	}


}
