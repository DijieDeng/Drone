package uk.ac.ed.inf.aqmaps;

public class LocationDetail {
	
	String country;
	String nearestPlace;
	String words;
	String language;
	String map;
	
	Square squareOnMap;
	public static class Square
	{
		Southwest southwest;
		public static class Southwest
		{
			double lng;
			double lat;
		}
		
		Northeast northeast;
		public static class Northeast
		{
			double lng;
			double lat;
		}
	}
	
	Coordinates coordinates;
	public static class Coordinates
	{
		double lng;
		double lat;
	}
}
