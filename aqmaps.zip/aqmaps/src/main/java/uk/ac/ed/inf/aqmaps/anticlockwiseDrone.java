package uk.ac.ed.inf.aqmaps;

import java.io.IOException;
import java.util.ArrayList;

import com.mapbox.geojson.Point;

public class anticlockwiseDrone extends Drone{

	public anticlockwiseDrone(double lat, double lng,String port) throws IOException, InterruptedException {
		super(lat, lng,port);
		// TODO Auto-generated constructor stub
	}
	
	public ArrayList<Point> ms(Point nextSensor) {
		Point cPoint = Point.fromLngLat(this.lng, this.lat);
		this.out = new ArrayList<>();
		this.out.add(cPoint);
		double theta=0;
		int steps = 0;
		
		do{//loop until the distance to next sensor is smaller than 0.0002 degree
			theta = anticlockwiseR(nextSensor);
			if(theta == -1) {return null;}
			this.lng = this.lng+0.0003*Math.cos(theta*(Math.PI/180));
			this.lat = this.lat+0.0003*Math.sin(theta*(Math.PI/180));
			cPoint = Point.fromLngLat(this.lng, this.lat);
			steps++;
			this.out.add(cPoint);
		}while(pointDis(cPoint, nextSensor)>0.0002 && steps < 150);
		
		return this.out;
	}
	
	public double anticlockwiseR(Point sensorLoc) {
		// TODO Auto-generated method stub
		double theta = super.angleToSensor(sensorLoc);
		
		int counter = 0;
		while(!(validMove((int) theta%360))) 
		{
			theta = (theta+10)%360;//rotate in the anticlockwise direction
			counter++;
			if(counter == 36) {return -1;}
		}

		return theta;
	}
	//return the route from the last position where the drone read the last sensor or the initial position
	public ArrayList<Point> getFlyRoute(Point nextSensor) {
		return this.ms(nextSensor);
	}
	
}
