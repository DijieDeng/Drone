package uk.ac.ed.inf.aqmaps;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mapbox.geojson.Feature;
import com.mapbox.geojson.FeatureCollection;
import com.mapbox.geojson.Point;


public class Map {
	
    private FeatureCollection fc;
    private ArrayList<Sensor> sensors = new ArrayList<Sensor>();
    
    public List<Point> locations = new ArrayList<Point>();
	public List<String> w3words = new ArrayList<String>();
    
    public Map(String mapString,String port) throws IOException, InterruptedException{
		//Download the json file, parse it into FeatureCollection
	    String mapJsonStr = JsonAPI.downloadAndParse(mapString);
	    
	    Type SensorListType = new TypeToken<ArrayList<Sensor>>() {}.getType();
	    sensors = new Gson().fromJson(mapJsonStr,SensorListType);
	    //take out the information we really need
	    ArrayList<Feature> fs = new ArrayList<>();
	    for(Sensor x : sensors) 
	    {
	    	fs.add(x.toFeature(port));
	    	this.locations.add(x.getCoordinate(port));
	    	this.w3words.add(x.location);
	    }
	    
	    this.fc = FeatureCollection.fromFeatures(fs);
	    
	}
	
	public FeatureCollection getFeatureCollection() {
		return this.fc;
	}
	
	public ArrayList<Sensor> getSensors()
	{
		return (ArrayList<Sensor>) this.sensors;
	}


}

