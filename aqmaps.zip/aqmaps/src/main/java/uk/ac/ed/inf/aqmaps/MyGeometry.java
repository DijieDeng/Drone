package uk.ac.ed.inf.aqmaps;

import java.util.ArrayList;

public class MyGeometry {
	String type;
	public ArrayList<Double[][]> coordinates;
	
	public String toString() {
		return type+" "+coordinates.size()+" "+coordinates.get(0).length+" "+" "+" ";
	}
	
}
