package uk.ac.ed.inf.aqmaps;

import java.io.IOException;
import java.util.ArrayList;

import com.mapbox.geojson.Feature;
import com.mapbox.geojson.Point;

public class Drone {
	
	final private double latUpLim = 55.946233;
	final private double latLowLim = 55.942617;
	final private double lngUpLim = -3.184319;
	final private double lngLowLim = -3.192473;
	
	private NoFlyZone nfz;
	
	protected double lat;
	protected double lng;
	protected String port;	
	final protected int[] addNumberTable = new int[] {0,10,-10,20,-20,30,-30,40,-40,50,-50,60,-60,70,-70,80,-80,90,-90,110,-110,120,-120,130,-130,140,-140,150,-150,160,-160,170,-170,180};
	protected ArrayList<Point> out = new ArrayList<>();
	
	public ArrayList<Point> all_point = new ArrayList<>();
	public ArrayList<Integer> readOnstepArrayList = new ArrayList<Integer>();
	
	public Drone(double lat, double lng,String port) throws IOException, InterruptedException {
		// TODO Auto-generated constructor stub
		this.lat = lat;
		this.lng = lng;
		this.port = port;
		this.nfz = new NoFlyZone(port);
		all_point.add(Point.fromLngLat(lng, lat));
	}
	
	public void threeDrones(Point nextSensor) throws IOException, InterruptedException{
		if(hitNoFlyZone(nextSensor)) {
			//3 subclasses to try doing the movement
			simpleDrone simp = new simpleDrone(this.lat,this.lng,port);
			clockwiseDrone clockwise = new clockwiseDrone(this.lat,this.lng,port);
			anticlockwiseDrone anti = new anticlockwiseDrone(this.lat, this.lng,port);

			var aWay = simp.getFlyRoute(nextSensor);
			var bWay = clockwise.getFlyRoute(nextSensor);
			var cWay = anti.getFlyRoute(nextSensor);
			ArrayList<Point> out = new ArrayList<>();
			
			//choose the best way to avoid the no-fly-zone
			if(simp.getRouteLength() < clockwise.getRouteLength()){
				if(simp.getRouteLength() < anti.getRouteLength()){
					out = aWay;
				}
				else {
					out = cWay;
				}
			}
			else {
				if(clockwise.getRouteLength()<anti.getRouteLength()){
					out = bWay;
				}
				else {
					out = cWay;
				}
			}
			this.lng = out.get(out.size()-1).longitude();
			this.lat = out.get(out.size()-1).latitude();
			for (int i = 0; i < out.size(); i++) {
				all_point.add(out.get(i));
				
			}
			readOnstepArrayList.add(all_point.size()-1);
			
		}
		else {
			moves(nextSensor);
		}
	}
	
	public void moves(Point nextSensor)
	{
		Point cPoint = Point.fromLngLat(this.lng, this.lat);
		this.out = new ArrayList<>();
		this.out.add(cPoint);
		//System.out.print(out.get(0));
		int mode = 0;
		double theta=0;
		
		//using do while to make sure it moves before read
		do{
			if(mode ==0) {theta = move(nextSensor);}
			else if (mode == 1) {
				theta = dfs(nextSensor);
			}
			if(theta == -1) {
				mode = (mode+1)%2;
				cPoint = this.out.get(0);
				this.out.clear();
				System.out.println(1);
				continue;
			}
			
			this.lng = this.lng+0.0003*Math.cos(theta*(Math.PI/180));
			this.lat = this.lat+0.0003*Math.sin(theta*(Math.PI/180));
			cPoint = Point.fromLngLat(this.lng, this.lat);
			
			this.out.add(cPoint);
			//System.out.println(cPoint);
			this.all_point.add(cPoint);
			
		}while(pointDis(cPoint, nextSensor)>0.0002);
		//record the step when we read the sensor
		readOnstepArrayList.add(all_point.size()-1);
		
	}
	
	public double move(Point sensorLoc){
		double theta = Math.toDegrees(Math.atan((this.lat-sensorLoc.latitude())/(this.lng-sensorLoc.longitude())));

		if(lng < sensorLoc.longitude()){
			if(lat > sensorLoc.latitude()){
				theta = Math.round((360+theta)/10)*10;
			}
			else {
				theta = Math.round((theta)/10)*10;
			}
		}
		else{
			theta = Math.round((theta+180)/10)*10;
		}
		
		int counter = 1;
		while (!(validMove((int) theta%360))) {
			theta = (theta-addNumberTable[counter]+addNumberTable[counter+1]+360)%360;
			counter++;
			if(counter == 33) {
				return -1;
			}
		}
		return theta;
	}
		
	public double dfs(Point sensorLoc) {
		// TODO Auto-generated method stub
		double theta = angleToSensor(sensorLoc);
		while(!(validMove((int) theta%360))) 
		{
			theta = (theta+10)%360;
		}
		return theta;
	}
	
	protected boolean validMove(int theta){
		double latAfterMov = this.lat+0.0003*Math.sin(theta*(Math.PI/180));
		double lngAfterMov = this.lng+0.0003*Math.cos(theta*(Math.PI/180));
		Point q2 = Point.fromLngLat(lngAfterMov, latAfterMov);
		
		if(hitNoFlyZone(q2)) {return false;}//crashes the no-fly-zone

		if(!(this.out == null)&&this.out.contains(q2)) {return false;}//avoid stuck between 2 points
		//lastly, make sure the drone is flying within the campus area
		return  (latAfterMov < latUpLim) && (latAfterMov > latLowLim)&&(lngAfterMov>lngLowLim)&&(lngAfterMov<lngUpLim);
	}

	//return if we crashed the no-fly-zone
	private boolean hitNoFlyZone(Point q2){
		for(int i = 0; i<4;i++){
			for(ArrayList<Double[]> line: nfz.polys.get(i)){
				Point p1 = Point.fromLngLat(line.get(0)[0], line.get(0)[1]);
				Point q1 = Point.fromLngLat(line.get(1)[0], line.get(1)[1]);
				Point p2 = Point.fromLngLat(this.lng, this.lat);
				if(nfz.doIntersect(p1,q1,p2,q2)){
					return true;
				}
			}
		}
		return false;
	}
			
	public boolean inRange(Point sensorLoc){
		double x = Math.sqrt((sensorLoc.latitude() - this.lat)*(sensorLoc.latitude() - this.lat) 
				+ (sensorLoc.longitude() - this.lng)*(sensorLoc.longitude() - this.lng));
		return x <= 0.0002;
	}
	
	protected double angleToSensor(Point sensorLoc) {
		double theta = Math.toDegrees(Math.atan((this.lat-sensorLoc.latitude())/(this.lng-sensorLoc.longitude())));
		
		if(lng < sensorLoc.longitude()){
			if(lat > sensorLoc.latitude()){
				theta = Math.round((360+theta)/10)*10;
			}
			else {
				theta = Math.round((theta)/10)*10;
			}
		}
		else{
			theta = Math.round((theta+180)/10)*10;
		}
		
		return theta;
	}

	public Feature readSensor(Sensor s) throws IOException, InterruptedException{
		Feature f = s.toFeature(this.port);
		//System.out.println(s.f.toJson());
		f = s.addStringProperty();
		return f;
	}
	
	public double pointDis(Point p1, Point p2) {
		double x = Math.sqrt((p1.latitude() - p2.latitude())*(p1.latitude() - p2.latitude()) 
				+ (p1.longitude() - p2.longitude())*(p1.longitude() - p2.longitude()));
		return x;
	}
	
	protected int getRouteLength() {
		if(this.out==null || this.out.isEmpty() || this.out.size()<1) {return Integer.MAX_VALUE;}
		return this.out.size();
	}

	

	
}
