package uk.ac.ed.inf.aqmaps;

import java.io.IOException;
import java.util.ArrayList;

import com.mapbox.geojson.Point;

public class simpleDrone extends Drone{
	private ArrayList<Double> all_angles = new ArrayList<>(); 


	public simpleDrone(double lat, double lng, String port) throws IOException, InterruptedException {
		super(lat, lng,port);
		// TODO Auto-generated constructor stub

	}
	
	private ArrayList<Point> simpSearch(Point nextSensor) {
		
		Point cPoint = Point.fromLngLat(this.lng, this.lat);//current point
		this.out = new ArrayList<>();
		double theta=0;
		int steps = 0;
		
		 do{//loop until the distance to next sensor is smaller than 0.0002 degree
			theta = rotates(nextSensor);//calculate the valid angle to the next sensor
			this.all_angles.add(theta);
			if(theta == -1) {
				this.out = null;
				return null;}
			this.lng = this.lng+0.0003*Math.cos(theta*(Math.PI/180));
			this.lat = this.lat+0.0003*Math.sin(theta*(Math.PI/180));
			cPoint = Point.fromLngLat(this.lng, this.lat);
			steps++;
			this.out.add(cPoint);
			//
			}while(pointDis(cPoint, nextSensor)>0.0002 && steps < 150);
		return this.out;
	}
	
	private double rotates(Point sensorLoc) {
		// TODO Auto-generated method stub
		double theta = super.angleToSensor(sensorLoc);
		
		int counter = 0;
		while(!(validMove((int) theta%360))) 
		{
			theta = (theta-super.addNumberTable[counter]+super.addNumberTable[counter+1]+360)%360;
			counter++;
			if(counter == 34) {
				return -1;
			}
		}

		return theta;
	}
	
	public ArrayList<Point> getFlyRoute(Point nextSensor) {
		return simpSearch(nextSensor);
	}
	
	public ArrayList<Double> getAngles(){
		return this.all_angles;
	}
	
}
