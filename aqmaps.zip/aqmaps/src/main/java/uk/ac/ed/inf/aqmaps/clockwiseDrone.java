package uk.ac.ed.inf.aqmaps;

import java.io.IOException;
import java.util.ArrayList;

import com.mapbox.geojson.Point;

public class clockwiseDrone extends Drone{

	public clockwiseDrone(double lat, double lng,String port) throws IOException, InterruptedException {
		super(lat, lng,port);
		// TODO Auto-generated constructor stub
	}
	
	private ArrayList<Point> clockwiseSearch(Point nextSensor) {
		Point cPoint = Point.fromLngLat(this.lng, this.lat);
		this.out = new ArrayList<>();
		this.out.add(cPoint);
		//System.out.print(out.get(0));
		double theta=0;
		int steps = 0;
		
		do{
			theta = clockwiseR(nextSensor);
			if(theta == -1) {return null;}
			this.lng = this.lng+0.0003*Math.cos(theta*(Math.PI/180));
			this.lat = this.lat+0.0003*Math.sin(theta*(Math.PI/180));
			cPoint = Point.fromLngLat(this.lng, this.lat);
			this.out.add(cPoint);
			steps++;
		}while(pointDis(cPoint, nextSensor)>0.0002 && steps < 150);
		return this.out;
	}
	
	private double clockwiseR(Point sensorLoc) {
		// TODO Auto-generated method stub
		double theta = super.angleToSensor(sensorLoc);
		
		int counter = 0;
		while(!(validMove((int) theta %360))) 
		{
			theta = (theta-10)%360;
			counter++;
			if(counter == 36) {
				return -1;}
		}
		return theta;
	}
	//return the route from the last position where the drone read the last sensor or the initial position
	public ArrayList<Point> getFlyRoute(Point nextSensor) {
		return this.clockwiseSearch(nextSensor);
	}
	
}
