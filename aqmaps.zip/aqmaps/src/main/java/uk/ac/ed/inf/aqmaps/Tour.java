package uk.ac.ed.inf.aqmaps;

import java.util.ArrayList;
import com.mapbox.geojson.Point;

public class Tour {

	public int[] seq = new int[33];
	
	private double[][] dists = new double[33][33];
	private Point init;
	private int startPoint;
	private ArrayList<Point> points;
	
	public Tour(ArrayList<Point> points,Point initPoint) {
		// TODO Auto-generated constructor stub
		this.init = initPoint;
		this.points = points;
		//Set the distance table between the points
		for(int i=0; i<33; i++){
			for(int j=0; j<33;j++){
				dists[i][j] = dis(points.get(i), points.get(j));
			}
			seq[i] = i;
		}
	}
	
	private double dis(Point point, Point initPoint) {
		// TODO Auto-generated method stub
		double x = Math.sqrt((point.latitude()-initPoint.latitude())*(point.latitude()-initPoint.latitude())
				+(point.longitude()-initPoint.longitude())*(point.longitude()-initPoint.longitude())); 
		return x;
	}

	public void greedy() {
		ArrayList<Integer> newSeq	= new ArrayList<>();
		double minDisFromInit = Double.MAX_VALUE;
		//work out the nearest point to the initial point
		for(int i = 0; i < 33; i++) {
			double x = dis(points.get(i), init);
			if(x < minDisFromInit){	
				minDisFromInit = x;
				startPoint = i;
			}
		}
		newSeq.add(startPoint);
		
		
		//greedy
		for(int i = 0; i < 32; i++){
			int k = -1;
			double min = Double.MAX_VALUE;
			for(int j = 0; j< 33; j++){
				if(!newSeq.contains(j)){
					if (dists[newSeq.get(i)][j] < min){
						min = dists[newSeq.get(i)][j];
						k = j;
						//
					}
				}
			}
			newSeq.add(k);
		}
		
		//save the result to the varible
		for(Integer i: newSeq){
			//System.out.print(i+" ");
			seq[newSeq.indexOf(i)] = i;
		}
	}
}
